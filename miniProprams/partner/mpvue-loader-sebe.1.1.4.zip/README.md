# mpvue-loader

>Webpack loader for mpvue components

本仓库是 fork 自 [vue-loader](https://github.com/mpvue/mpvue-loader) 修改而来，主要为 webpack 打包 mpvue components 提供能力。

